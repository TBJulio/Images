

作者全平台名称：BLZ  【所有在BLZ的页面以外下载的都是盗传！谨防被骗 】
All platform : BLZ   【All downloads outside of BLZ's page are pirated!  Beware of scams】

作者Artist：BLZ
Twitter : @BLZ_pixel
Ko-fi : ko-fi.com/blz_404
Vgen : vgen.co/BLZ
Bilibili : space.bilibili.com/2255628

*禁止转载，转载必究
*禁止二次贩卖，禁止修改
*禁止上传至任何软件或网站
*Please do not claim or rename the files as your own.
*Secondary sale and modification are prohibited
*Reproduction is prohibited.
*Uploadi to any software or website is prohibited.
